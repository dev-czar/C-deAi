'use client'

import { useState } from 'react'
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card } from "@/components/ui/card"
import { Play, Send } from 'lucide-react'
import { LoadingSpinner } from './loading-spinner'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface CodeEditorProps {
  onExecute: (code: string, language: string) => void
  onAskAI: (prompt: string, language: string) => Promise<void>
  isLoading: boolean
  isPythonAvailable: boolean
}

export function CodeEditor({ onExecute, onAskAI, isLoading, isPythonAvailable }: CodeEditorProps) {
  const [code, setCode] = useState('')
  const [prompt, setPrompt] = useState('')
  const [language, setLanguage] = useState('javascript')

  const handleAskAI = async () => {
    if (prompt.trim()) {
      await onAskAI(prompt, language)
      setPrompt('')
    }
  }

  return (
    <div className="grid gap-4">
      <Card className="p-4">
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Textarea
              placeholder="Ask AI to generate code..."
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              className="min-h-[60px]"
              disabled={isLoading}
            />
            <Button 
              onClick={handleAskAI} 
              className="shrink-0"
              disabled={isLoading || !prompt.trim()}
            >
              {isLoading ? (
                <LoadingSpinner />
              ) : (
                <>
                  <Send className="h-4 w-4 mr-2" />
                  Ask AI
                </>
              )}
            </Button>
          </div>
        </div>
      </Card>
      
      <Card className="p-4">
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <Select value={language} onValueChange={setLanguage}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select Language" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="javascript">JavaScript</SelectItem>
                <SelectItem value="python" disabled={!isPythonAvailable}>
                  Python {!isPythonAvailable && '(Unavailable)'}
                </SelectItem>
                <SelectItem value="html">HTML</SelectItem>
              </SelectContent>
            </Select>
            <Button 
              onClick={() => onExecute(code, language)}
              disabled={!code.trim()}
            >
              <Play className="h-4 w-4 mr-2" />
              Run Code
            </Button>
          </div>
          <Textarea
            placeholder="Write or paste code here..."
            value={code}
            onChange={(e) => setCode(e.target.value)}
            className="font-mono min-h-[200px]"
          />
        </div>
      </Card>
    </div>
  )
}

