import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Code2, Home, User } from 'lucide-react'

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-gray-800 bg-black/50 backdrop-blur-md supports-[backdrop-filter]:bg-black/20">
      <div className="container flex h-14 items-center">
        <Link href="/" className="flex items-center space-x-2">
          <Code2 className="h-6 w-6 text-blue-500" />
          <span className="font-bold text-xl bg-clip-text text-transparent bg-gradient-to-r from-blue-500 to-purple-500">CodeAI</span>
        </Link>
        <nav className="flex items-center space-x-6 mx-6">
          <Link
            href="/"
            className="text-sm font-medium transition-colors hover:text-blue-500"
          >
            <Home className="h-4 w-4" />
          </Link>
          <Link
            href="/playground"
            className="text-sm font-medium transition-colors hover:text-blue-500"
          >
            Playground
          </Link>
          <Link
            href="/snippets"
            className="text-sm font-medium transition-colors hover:text-blue-500"
          >
            My Snippets
          </Link>
        </nav>
        <div className="ml-auto flex items-center space-x-4">
          <Button variant="ghost" size="icon" className="text-blue-500 hover:text-blue-400">
            <User className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </header>
  )
}

