'use client'

import { Card } from '@/components/ui/card'
import { CodeBlock } from './code-block'
import { SaveSnippetDialog } from './save-snippet-dialog'

interface CodeOutputProps {
  output: string
  language: string
  onSaveSnippet?: (title: string, description: string) => void
}

export function CodeOutput({ output, language, onSaveSnippet }: CodeOutputProps) {
  return (
    <Card className="p-4">
      <div className="flex items-center justify-between mb-4">
        <h2 className="font-semibold">Output:</h2>
        {onSaveSnippet && output && (
          <SaveSnippetDialog code={output} onSave={onSaveSnippet} />
        )}
      </div>
      <div className="rounded-lg overflow-hidden">
        {language === 'html' ? (
          <div dangerouslySetInnerHTML={{ __html: output }} />
        ) : (
          <CodeBlock code={output} language={language} />
        )}
      </div>
    </Card>
  )
}

