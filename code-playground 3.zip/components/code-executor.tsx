'use client'

import { useState } from 'react'

export async function executeCode(code: string, language: string): Promise<string> {
  if (language === 'javascript') {
    return executeJavaScript(code)
  } else if (language === 'python') {
    return executePython(code)
  } else if (language === 'html') {
    return executeHTML(code)
  }
  throw new Error('Unsupported language')
}

function executeJavaScript(code: string): string {
  let output = ''
  const originalConsole = console.log
  console.log = (...args) => {
    output += args.join(' ') + '\n'
  }

  try {
    const sandboxedCode = new Function('console', `
      "use strict";
      ${code}
    `)
    sandboxedCode(console)
  } catch (error) {
    output += 'Error: ' + error.message
  }

  console.log = originalConsole
  return output
}

async function executePython(code: string): Promise<string> {
  try {
    const response = await fetch('/api/python-execute', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ code }),
    })

    if (!response.ok) {
      throw new Error('Failed to execute Python code')
    }

    const data = await response.json()
    return data.output
  } catch (error) {
    return 'Error: ' + (error as Error).message
  }
}

function executeHTML(code: string): Promise<string> {
  return new Promise((resolve) => {
    const iframe = document.createElement('iframe')
    iframe.style.display = 'none'
    iframe.sandbox.add('allow-scripts')
    document.body.appendChild(iframe)

    const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document
    if (iframeDoc) {
      iframeDoc.open()
      iframeDoc.write(code)
      iframeDoc.close()
    }

    setTimeout(() => {
      const output = iframe.contentWindow?.document.body.innerHTML || ''
      document.body.removeChild(iframe)
      resolve(output)
    }, 1000)
  })
}

export function useCodeExecution() {
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const execute = async (code: string, language: string) => {
    setIsLoading(true)
    setError(null)
    try {
      const result = await executeCode(code, language)
      return result
    } catch (err) {
      setError((err as Error).message)
      return 'Error: ' + (err as Error).message
    } finally {
      setIsLoading(false)
    }
  }

  return { execute, isLoading, error }
}

