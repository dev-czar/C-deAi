import { Button } from "@/components/ui/button"
import { Code2, Sparkles, Save } from 'lucide-react'
import Link from "next/link"

export default function Home() {
  return (
    <div className="flex flex-col items-center justify-center min-h-[calc(100vh-3.5rem)] relative overflow-hidden">
      <div className="container px-4 py-16 mx-auto text-center z-10">
        <h1 className="text-5xl font-bold tracking-tight sm:text-7xl mb-6 bg-clip-text text-transparent bg-gradient-to-r from-blue-500 to-purple-500">
          Code with AI Assistance
        </h1>
        <p className="mt-6 text-xl leading-8 text-gray-300 max-w-2xl mx-auto">
          Generate, test, and save code snippets with AI assistance. Perfect for learning, prototyping, and solving coding challenges.
        </p>
        <div className="mt-10 flex items-center justify-center gap-x-6">
          <Button asChild size="lg" className="bg-blue-600 hover:bg-blue-700 text-white">
            <Link href="/playground">
              Try Playground
              <Code2 className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
        
        <div className="mt-20 grid gap-8 md:grid-cols-3">
          <div className="flex flex-col items-center p-6 bg-gray-800/50 rounded-lg backdrop-blur-sm">
            <Sparkles className="h-10 w-10 mb-4 text-blue-500" />
            <h2 className="text-xl font-semibold mb-2 text-blue-400">AI-Powered</h2>
            <p className="text-gray-300 text-center">
              Generate code snippets using natural language with AI assistance
            </p>
          </div>
          <div className="flex flex-col items-center p-6 bg-gray-800/50 rounded-lg backdrop-blur-sm">
            <Code2 className="h-10 w-10 mb-4 text-blue-500" />
            <h2 className="text-xl font-semibold mb-2 text-blue-400">Live Testing</h2>
            <p className="text-gray-300 text-center">
              Test your code instantly in a secure sandbox environment
            </p>
          </div>
          <div className="flex flex-col items-center p-6 bg-gray-800/50 rounded-lg backdrop-blur-sm">
            <Save className="h-10 w-10 mb-4 text-blue-500" />
            <h2 className="text-xl font-semibold mb-2 text-blue-400">Save Snippets</h2>
            <p className="text-gray-300 text-center">
              Save and organize your code snippets for future reference
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

