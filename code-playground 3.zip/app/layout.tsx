import { Inter } from 'next/font/google'
import { SiteHeader } from '@/components/site-header'
import { Toaster } from '@/components/ui/toaster'
import { ParticleBackground } from '@/components/particle-background'
import './globals.css'

const inter = Inter({ subsets: ['latin'] })

export const metadata = {
  title: 'CodeAI Playground',
  description: 'Generate and test code with AI',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className="dark">
      <body className={`${inter.className} bg-gradient-to-br from-gray-900 to-black text-white min-h-screen`}>
        <ParticleBackground />
        <div className="relative z-10">
          <SiteHeader />
          <main>{children}</main>
          <Toaster />
        </div>
      </body>
    </html>
  )
}

