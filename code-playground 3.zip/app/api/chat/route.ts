import { generateText } from 'ai'
import { OpenAI } from '@ai-sdk/openai'
import { NextResponse } from 'next/server'

export const maxDuration = 30

export async function POST(req: Request) {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return NextResponse.json(
        { error: 'OpenAI API key not configured' },
        { status: 500 }
      )
    }

    const { prompt, language } = await req.json()
    
    const openai = new OpenAI(process.env.OPENAI_API_KEY)
    
    const { text } = await generateText({
      model: openai(process.env.OPENAI_API_MODEL || 'gpt-4'),
      prompt: `You are a helpful coding assistant. Please provide working ${language} code for the following request: ${prompt}`,
      system: `You are an expert ${language} programmer. Provide clean, working code with brief explanations.`
    })

    return NextResponse.json({ code: text })
  } catch (error) {
    console.error('API Error:', error)
    return NextResponse.json(
      { error: 'Failed to generate code' },
      { status: 500 }
    )
  }
}

