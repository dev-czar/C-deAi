import { NextResponse } from 'next/server'
import { exec } from 'child_process'
import { promisify } from 'util'
import fs from 'fs/promises'
import path from 'path'

const execAsync = promisify(exec)

export async function POST(req: Request) {
  try {
    const { code } = await req.json()

    // Create a temporary directory
    const tempDir = path.join('/tmp', 'python-' + Date.now())
    await fs.mkdir(tempDir, { recursive: true })

    // Write the Python code to a file
    const filePath = path.join(tempDir, 'script.py')
    await fs.writeFile(filePath, code)

    // Execute the Python script
    const { stdout, stderr } = await execAsync(`python ${filePath}`)

    // Clean up the temporary directory
    await fs.rm(tempDir, { recursive: true, force: true })

    if (stderr) {
      return NextResponse.json({ output: stderr }, { status: 400 })
    }

    return NextResponse.json({ output: stdout })
  } catch (error) {
    console.error('Python execution error:', error)
    return NextResponse.json({ output: 'Internal server error' }, { status: 500 })
  }
}

