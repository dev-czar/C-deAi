'use client'

import { useState, useEffect } from 'react'
import { CodeEditor } from '@/components/code-editor'
import { CodeOutput } from '@/components/code-output'
import { useToast } from '@/components/ui/use-toast'
import { useCodeExecution } from '@/components/code-executor'
import { LoadingSpinner } from '@/components/loading-spinner'
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle } from 'lucide-react'

export default function Playground() {
  const [output, setOutput] = useState('')
  const [language, setLanguage] = useState('javascript')
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()
  const { execute, isLoading: isExecuting, error: executionError } = useCodeExecution()

  useEffect(() => {
    if (isExecuting) {
      toast({
        title: 'Loading',
        description: 'Executing code...',
      })
    } else if (executionError) {
      toast({
        title: 'Error',
        description: executionError,
        variant: 'destructive',
      })
    }
  }, [isExecuting, executionError, toast])

  const handleExecuteCode = async (code: string, lang: string) => {
    setIsLoading(true)
    try {
      const result = await execute(code, lang)
      setOutput(result)
      setLanguage(lang)
    } catch (error: any) {
      setOutput(`Error: ${error.message}`)
    } finally {
      setIsLoading(false)
    }
  }

  const askAI = async (prompt: string, lang: string) => {
    setIsLoading(true)
    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ prompt, language: lang }),
      })

      if (!response.ok) {
        throw new Error('Failed to generate code')
      }

      const data = await response.json()
      if (data.error) {
        throw new Error(data.error)
      }
      
      setOutput(data.code)
      setLanguage(lang)
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to generate code. Please try again.',
        variant: 'destructive',
      })
    } finally {
      setIsLoading(false)
    }
  }

  const saveSnippet = (title: string, description: string) => {
    const snippets = JSON.parse(localStorage.getItem('codeSnippets') || '[]')
    const newSnippet = {
      id: Date.now().toString(),
      title,
      description,
      code: output,
      language,
      createdAt: new Date().toISOString(),
    }
    
    localStorage.setItem('codeSnippets', JSON.stringify([...snippets, newSnippet]))
    
    toast({
      title: 'Success',
      description: 'Code snippet saved successfully!',
    })
  }


  return (
    <div className="container py-10 max-w-4xl">
      <h1 className="text-4xl font-bold mb-8">Code Playground</h1>
      {executionError && (
        <Alert variant="destructive" className="mb-6">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{executionError}</AlertDescription>
        </Alert>
      )}
      <div className="grid gap-6">
        <CodeEditor 
          onExecute={handleExecuteCode} 
          onAskAI={askAI}
          isLoading={isExecuting || isLoading}
          isPythonAvailable={true}
        />
        <CodeOutput 
          output={output}
          language={language}
          onSaveSnippet={saveSnippet}
        />
      </div>
    </div>
  )
}

