'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { CodeBlock } from '@/components/code-block'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface Snippet {
  id: string
  title: string
  description: string
  code: string
  language: string
  createdAt: string
}

export default function SnippetsPage() {
  const [snippets, setSnippets] = useState<Snippet[]>([])
  const [selectedLanguage, setSelectedLanguage] = useState<string>('all')

  useEffect(() => {
    // Load snippets from localStorage
    const savedSnippets = localStorage.getItem('codeSnippets')
    if (savedSnippets) {
      setSnippets(JSON.parse(savedSnippets))
    }
  }, [])

  const filteredSnippets = selectedLanguage === 'all'
    ? snippets
    : snippets.filter(snippet => snippet.language === selectedLanguage)

  return (
    <div className="container py-10">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-4xl font-bold">My Snippets</h1>
        <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Filter by language" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Languages</SelectItem>
            <SelectItem value="javascript">JavaScript</SelectItem>
            <SelectItem value="python">Python</SelectItem>
            <SelectItem value="html">HTML</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="grid gap-6 md:grid-cols-2">
        {filteredSnippets.map((snippet) => (
          <Card key={snippet.id}>
            <CardHeader>
              <CardTitle>{snippet.title}</CardTitle>
              <CardDescription>{snippet.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-sm text-muted-foreground mb-2">
                Language: {snippet.language}
              </div>
              <CodeBlock code={snippet.code} language={snippet.language} />
            </CardContent>
          </Card>
        ))}
        {filteredSnippets.length === 0 && (
          <p className="text-muted-foreground col-span-2 text-center py-8">
            No saved snippets yet. Save some code from the playground!
          </p>
        )}
      </div>
    </div>
  )
}

